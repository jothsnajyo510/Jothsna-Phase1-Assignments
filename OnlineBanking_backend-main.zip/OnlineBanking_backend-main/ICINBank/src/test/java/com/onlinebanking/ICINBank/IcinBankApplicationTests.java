package com.onlinebanking.ICINBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcinBankApplicationTests {

	@Test
	void contextLoads() {
	}
}